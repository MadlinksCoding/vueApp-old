"use strict";

// cart.js (Node.js + Scylla Alternator)

// ───────────────────────────────────────────────────────────────
// ✅ Required Modules
// ───────────────────────────────────────────────────────────────
const ScyllaDb = require('./mocks/ScyllaDb'); // Mocked for testing
const Logger = require('./utils/Logger');
const DateTime = require('./utils/DateTime');
const SafeUtils = require('./utils/SafeUtils');
const EnvLoader = require('./utils/EnvLoader');
const ErrorHandler = require('./utils/ErrorHandler');
const ConfigFileLoader = require('./utils/ConfigFileLoader');

// ───────────────────────────────────────────────────────────────
// 📦 Constants (Static Values - Non-Environment)
// ───────────────────────────────────────────────────────────────
const DISCOUNT_TYPE_FIXED = 'fixed';
const DISCOUNT_TYPE_PERCENTAGE = 'percentage';

const FEE_TYPE_FIXED = 'fixed';
const FEE_TYPE_PERCENTAGE = 'percentage';

const CART_TYPE_STANDARD = 'standard';
const CART_TYPE_SHARED = 'shared';
const CART_TYPE_COLLABORATIVE = 'collaborative';
const CART_TYPE_WISHLIST = 'wishlist';

const TABLE_CARTS = 'carts';
const TABLE_CART_INDEX = 'user_carts_index';

const FIELD_DEFAULT_FLAG = 'is_default';
const FIELD_CART_TYPE = 'cart_type';
const FIELD_ITEMS = 'items';
const FIELD_FEES = 'fees';
const FIELD_DISCOUNTS = 'discounts';

// Default fallback values for environment variables
const DEFAULT_CART_TTL_MS = 15552000000; // ~180 days
const DEFAULT_MAX_CART_TOTAL = 500;
const DEFAULT_MIN_CART_TOTAL = 5;
const DEFAULT_MAX_ITEMS_PER_CART = 100;
const DEFAULT_API_PRODUCT_LOOKUP_URL = 'https://your-api.com/products/';
const DEFAULT_VENDOR_NAME = 'model';

// Validation constants
const MAX_QUANTITY_PER_ITEM = 10000;
const MAX_STRING_LENGTH = 255;
const MAX_LABEL_LENGTH = 100;
const MAX_USER_ID_LENGTH = 128;
const MAX_FEE_VALUE = 1000000;
const PERCENTAGE_DIVISOR = 100;
const MS_TO_SECONDS = 1000;
const MAX_TRANSACTION_ITEMS = 25;
const DANGEROUS_KEYS = ['__proto__', 'constructor', 'prototype'];
const COUPON_CODE_PATTERN = /^[A-Z0-9]{4,20}$/;
const VENDOR_FORMAT_PATTERN = /^[a-zA-Z0-9_-]+$/;
const USER_ID_FORMAT_PATTERN = /^[a-zA-Z0-9_-]+$/;

// ───────────────────────────────────────────────────────────────
// 🧠 Static Cart Class
// ───────────────────────────────────────────────────────────────
class Cart {
  // Environment variables accessed through process.env
  static ENV = process.env;

  // Static environment-based constants
  static CART_TTL_MILLISECONDS;
  static MAX_CART_TOTAL;
  static MIN_CART_TOTAL;
  static MAX_ITEMS_PER_CART;
  static API_PRODUCT_LOOKUP_URL;
  static DEFAULT_VENDOR;

  // Static initialization block
  static {
    // Ensure environment is loaded
    EnvLoader.ensureEnv();

    // Ensure ENV is available
    if (!Cart.ENV) {
      ErrorHandler.addError("Cart ENV not available", {
        code: "ENV_NOT_AVAILABLE",
        level: "error",
        origin: "Cart",
        timestamp: DateTime.now(),
      });
      throw new Error("ENV");
    }

    // Validate cart-specific environment section
    try {
      EnvLoader.validateEnv("cart");
    } catch (err) {
      ErrorHandler.addError("Cart env validation failed", {
        code: "CART_ENV_VALIDATION_FAILED",
        level: "error",
        origin: "Cart",
        error: err?.message || "unknown",
        timestamp: DateTime.now(),
      });
      throw err;
    }

    // Initialize environment-based constants with named defaults
    const cartTTL = parseInt(Cart.ENV.CART_TTL_MILLISECONDS);
    Cart.CART_TTL_MILLISECONDS = (Number.isNaN(cartTTL) || cartTTL <= 0) ? DEFAULT_CART_TTL_MS : cartTTL;

    const maxTotal = parseInt(Cart.ENV.MAX_CART_TOTAL);
    Cart.MAX_CART_TOTAL = (Number.isNaN(maxTotal) || maxTotal <= 0) ? DEFAULT_MAX_CART_TOTAL : maxTotal;

    const minTotal = parseInt(Cart.ENV.MIN_CART_TOTAL);
    Cart.MIN_CART_TOTAL = (Number.isNaN(minTotal) || minTotal <= 0) ? DEFAULT_MIN_CART_TOTAL : minTotal;

    const maxItems = parseInt(Cart.ENV.MAX_ITEMS_PER_CART);
    Cart.MAX_ITEMS_PER_CART = (Number.isNaN(maxItems) || maxItems <= 0) ? DEFAULT_MAX_ITEMS_PER_CART : maxItems;

    Cart.API_PRODUCT_LOOKUP_URL = Cart.ENV.API_PRODUCT_LOOKUP_URL || DEFAULT_API_PRODUCT_LOOKUP_URL;
    Cart.DEFAULT_VENDOR = Cart.ENV.DEFAULT_VENDOR || DEFAULT_VENDOR_NAME;

    // Log successful initialization
    ErrorHandler.addError("Cart class initialized", {
      code: "CART_INITIALIZED",
      level: "info",
      origin: "Cart",
      timestamp: DateTime.now(),
    });
  }
  static async addItem(sessionId, productId, quantity, type = CART_TYPE_STANDARD, vendor = Cart.DEFAULT_VENDOR) {
    const operationName = 'addItemToCart';

    // Sanitize and validate all input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      productId: { value: productId, type: "string", required: true },
      quantity: { value: quantity, type: "integer", required: true },
      type: { value: type, type: "string", required: false, default: CART_TYPE_STANDARD },
      vendor: { value: vendor, type: "string", required: false, default: Cart.DEFAULT_VENDOR }
    }, operationName);

    const { sessionId: cleanSessionId, productId: cleanProductId, quantity: cleanQuantity, type: cleanType, vendor: cleanVendor } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [addItem] [START] Adding item to cart: sessionId=${cleanSessionId}, productId=${cleanProductId}, quantity=${cleanQuantity}`);

    try {
      // Validate input lengths
      if (cleanSessionId.length > MAX_STRING_LENGTH || cleanProductId.length > MAX_STRING_LENGTH) {
        ErrorHandler.addError("Input length exceeds maximum allowed", {
          code: "INPUT_LENGTH_EXCEEDED",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId.substring(0, 50),
          timestamp: DateTime.now(),
        });
        throw new Error('Input length exceeds maximum allowed');
      }

      // Validate empty strings after sanitization
      if (!cleanSessionId || cleanSessionId.trim().length === 0 || !cleanProductId || cleanProductId.trim().length === 0) {
        ErrorHandler.addError("Empty value detected after sanitization", {
          code: "EMPTY_VALUE_DETECTED",
          level: "error",
          origin: "Cart",
          timestamp: DateTime.now(),
        });
        throw new Error('Session ID and Product ID cannot be empty');
      }

      // Validate against prototype pollution
      if (DANGEROUS_KEYS.includes(cleanProductId)) {
        ErrorHandler.addError("Dangerous key detected - potential prototype pollution", {
          code: "DANGEROUS_KEY_DETECTED",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          productId: cleanProductId,
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      // Validate quantity range
      if (cleanQuantity <= 0 || cleanQuantity > MAX_QUANTITY_PER_ITEM) {
        ErrorHandler.addError("Invalid quantity specified", {
          code: "INVALID_QUANTITY",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          productId: cleanProductId,
          quantity: cleanQuantity,
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid quantity value');
      }

      // Validate cart type parameter
      if (![CART_TYPE_STANDARD, CART_TYPE_SHARED, CART_TYPE_COLLABORATIVE, CART_TYPE_WISHLIST].includes(cleanType)) {
        ErrorHandler.addError("Invalid cart type specified", {
          code: "INVALID_CART_TYPE",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          invalidType: cleanType,
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid cart type');
      }

      // Validate vendor format
      if (!VENDOR_FORMAT_PATTERN.test(cleanVendor)) {
        ErrorHandler.addError("Invalid vendor format", {
          code: "INVALID_VENDOR_FORMAT",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          vendor: cleanVendor,
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid vendor format');
      }

      const cart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });

      // Initialize cart with metadata if it doesn't exist
      if (!cart || !cart.session_id) {
        const nowTimestamp = DateTime.now();
        const createdAtTimestamp = typeof nowTimestamp === 'number' ? Math.floor(nowTimestamp / MS_TO_SECONDS) : Math.floor(Date.now() / MS_TO_SECONDS);

        await ScyllaDb.putItem(TABLE_CARTS, {
          session_id: cleanSessionId,
          items: { [cleanProductId]: { quantity: cleanQuantity, type: cleanType, vendor: cleanVendor } },
          cart_type: CART_TYPE_STANDARD,
          created_at: createdAtTimestamp,
          fees: {},
          discounts: {}
        });

        Logger.debugLog?.(`[Cart] [addItem] [SUCCESS] Created new cart and added item: sessionId=${cleanSessionId}, productId=${cleanProductId}`);
        return Cart;
      }

      const items = cart.items || {};
      const itemKeys = Object.keys(items);

      // Check item limits only for new items
      if (!items[cleanProductId] && itemKeys.length >= Cart.MAX_ITEMS_PER_CART) {
        ErrorHandler.addError("Cart item limit reached", {
          code: "CART_ITEM_LIMIT_EXCEEDED",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          currentItemCount: itemKeys.length,
          maxAllowed: Cart.MAX_ITEMS_PER_CART,
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      // Check if item already exists in the cart, preserve existing properties when updating
      if (items[cleanProductId]) {
        items[cleanProductId] = { ...items[cleanProductId], quantity: cleanQuantity, type: cleanType, vendor: cleanVendor };
      } else {
        items[cleanProductId] = { quantity: cleanQuantity, type: cleanType, vendor: cleanVendor };
      }

      await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { items });

      Logger.debugLog?.(`[Cart] [addItem] [SUCCESS] Successfully added item to cart: sessionId=${cleanSessionId}, productId=${cleanProductId}, quantity=${cleanQuantity}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "ADD_ITEM_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        productId: cleanProductId,
        quantity: cleanQuantity,
        type: cleanType,
        vendor: cleanVendor,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "addItemToCart",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, productId: cleanProductId, quantity: cleanQuantity, type: cleanType, vendor: cleanVendor, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async removeItem(sessionId, productId) {
    const operationName = 'removeItemFromCart';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      productId: { value: productId, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId, productId: cleanProductId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [removeItem] [START] Removing item from cart: sessionId=${cleanSessionId}, productId=${cleanProductId}`);

    try {
      const cart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });
      if (cart?.items?.[cleanProductId]) {
        delete cart.items[cleanProductId];
        await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { items: cart.items });

        Logger.debugLog?.(`[Cart] [removeItem] [SUCCESS] Successfully removed item from cart: sessionId=${cleanSessionId}, productId=${cleanProductId}`);
      }
      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "REMOVE_ITEM_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        productId: cleanProductId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "removeItemFromCart",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, productId: cleanProductId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async updateQuantity(sessionId, productId, quantity) {
    const operationName = 'updateItemQuantityInCart';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      productId: { value: productId, type: "string", required: true },
      quantity: { value: quantity, type: "integer", required: true }
    }, operationName);

    const { sessionId: cleanSessionId, productId: cleanProductId, quantity: cleanQuantity } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [updateQuantity] [START] Updating item quantity in cart: sessionId=${cleanSessionId}, productId=${cleanProductId}, quantity=${cleanQuantity}`);

    try {
      // Validate quantity range
      if (cleanQuantity <= 0 || cleanQuantity > MAX_QUANTITY_PER_ITEM) {
        ErrorHandler.addError("Invalid quantity specified", {
          code: "INVALID_QUANTITY",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          productId: cleanProductId,
          quantity: cleanQuantity,
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid quantity value');
      }

      const cart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });
      if (!cart?.items?.[cleanProductId]) {
        ErrorHandler.addError("Item not found in cart", {
          code: "ITEM_NOT_FOUND",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          productId: cleanProductId,
          timestamp: DateTime.now(),
        });
        throw new Error('Item not found');
      }

      cart.items[cleanProductId].quantity = cleanQuantity;
      await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { items: cart.items });

      Logger.debugLog?.(`[Cart] [updateQuantity] [SUCCESS] Successfully updated item quantity: sessionId=${cleanSessionId}, productId=${cleanProductId}, newQuantity=${cleanQuantity}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "UPDATE_QUANTITY_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        productId: cleanProductId,
        quantity: cleanQuantity,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "updateItemQuantityInCart",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, productId: cleanProductId, quantity: cleanQuantity, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async getItems(sessionId) {
    const operationName = 'getItemsFromCart';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [getItems] [START] Retrieving items from cart: sessionId=${cleanSessionId}`);

    try {
      const cart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });

      const items = cart?.items || {};
      Logger.debugLog?.(`[Cart] [getItems] [SUCCESS] Retrieved ${Object.keys(items).length} items from cart: sessionId=${cleanSessionId}`);

      return items;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "GET_ITEMS_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "getItemsFromCart",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async renameCart(sessionId, label) {
    const operationName = 'renameCartLabel';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      label: { value: label, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId, label: cleanLabel } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [renameCart] [START] Renaming cart: sessionId=${cleanSessionId}, newLabel=${cleanLabel}`);

    try {
      // Additional validation for label
      const sanitizedLabel = SafeUtils.sanitizeTextField(cleanLabel);
      if (!sanitizedLabel || sanitizedLabel.length > MAX_LABEL_LENGTH) {
        ErrorHandler.addError("Invalid cart label specified", {
          code: "INVALID_CART_LABEL",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          label: cleanLabel,
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { label: sanitizedLabel });

      Logger.debugLog?.(`[Cart] [renameCart] [SUCCESS] Successfully renamed cart: sessionId=${cleanSessionId}, label=${sanitizedLabel}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "RENAME_CART_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        label: cleanLabel,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "renameCartLabel",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, label: cleanLabel, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async setAsDefault(sessionId, userId, onlyThis = true) {
    const operationName = 'setCartAsDefault';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      userId: { value: userId, type: "string", required: true },
      onlyThis: { value: onlyThis, type: "boolean", required: false, default: true }
    }, operationName);

    const { sessionId: cleanSessionId, userId: cleanUserId, onlyThis: cleanOnlyThis } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [setAsDefault] [START] Setting cart as default: sessionId=${cleanSessionId}, userId=${cleanUserId}, onlyThis=${cleanOnlyThis}`);

    try {
      if (cleanOnlyThis) {
        const keyConditionExpr = 'user_id = :uid';
        const existingResult = await ScyllaDb.query(TABLE_CART_INDEX, keyConditionExpr, {
          ':uid': cleanUserId
        });
        const existing = Array.isArray(existingResult) ? existingResult : (existingResult ? [existingResult] : []);

        // Filter out the target sessionId to avoid key collision in transaction
        const otherCarts = existing.filter((item) => item.session_id !== cleanSessionId);

        // Chunk operations into batches of 25 for Alternator limits
        const batchSize = 25;
        const batches = [];
        for (let i = 0; i < otherCarts.length; i += batchSize) {
          batches.push(otherCarts.slice(i, i + batchSize));
        }

        // Process batch transactions
        for (const batch of batches) {
          const transactWriteOperations = batch.map((item) => {
            return {
              table: TABLE_CART_INDEX,
              action: 'update',
              key: { user_id: item.user_id, session_id: item.session_id },
              data: {
                is_default: false
              }
            };
          });

          try {
            await ScyllaDb.transactWrite(transactWriteOperations, {
              rollbackOnFailure: true
            });
          } catch (transactError) {
            ErrorHandler.addError("Transaction batch write failed, rollback initiated", {
              code: "TRANSACT_WRITE_FAILED",
              level: "error",
              origin: "Cart",
              operation: "setAsDefault",
              sessionId: cleanSessionId,
              userId: cleanUserId,
              operationCount: transactWriteOperations.length,
              error: transactError.message,
              timestamp: DateTime.now(),
            });
            throw transactError;
          }
        }

        // Set target cart as default
        const defaultOperation = [{
          table: TABLE_CART_INDEX,
          action: 'update',
          key: { user_id: cleanUserId, session_id: cleanSessionId },
          data: {
            is_default: true
          }
        }];

        try {
          await ScyllaDb.transactWrite(defaultOperation, {
            rollbackOnFailure: true
          });
          
          // Verify transaction succeeded by reading back the state
          const verifyResult = await ScyllaDb.query(TABLE_CART_INDEX, 'user_id = :uid', { ':uid': cleanUserId });
          const defaultCount = (Array.isArray(verifyResult) ? verifyResult : []).filter(c => c.is_default).length;
          
          if (defaultCount !== 1) {
            ErrorHandler.addError("Transaction state verification failed - multiple defaults detected", {
              code: "TRANSACT_VERIFY_FAILED",
              level: "error",
              origin: "Cart",
              userId: cleanUserId,
              defaultCartCount: defaultCount,
              timestamp: DateTime.now(),
            });
            throw new Error('Operation failed');
          }
        } catch (transactError) {
          ErrorHandler.addError("Failed to set default cart, rollback initiated", {
            code: "TRANSACT_WRITE_FAILED",
            level: "error",
            origin: "Cart",
            operation: "setAsDefault",
            sessionId: cleanSessionId,
            userId: cleanUserId,
            error: transactError.message,
            timestamp: DateTime.now(),
          });
          throw transactError;
        }
      } else {
        await ScyllaDb.updateItem(
          TABLE_CART_INDEX,
          { user_id: cleanUserId, session_id: cleanSessionId },
          { is_default: true }
        );
      }

      Logger.debugLog?.(`[Cart] [setAsDefault] [SUCCESS] Successfully set cart as default: sessionId=${cleanSessionId}, userId=${cleanUserId}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "SET_AS_DEFAULT_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        userId: cleanUserId,
        onlyThis: cleanOnlyThis,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "setCartAsDefault",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, userId: cleanUserId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async setCartType(sessionId, type) {
    const operationName = 'setCartType';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      type: { value: type, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId, type: cleanType } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [setCartType] [START] Setting cart type: sessionId=${cleanSessionId}, type=${cleanType}`);

    try {
      if (
        ![
          CART_TYPE_STANDARD,
          CART_TYPE_SHARED,
          CART_TYPE_COLLABORATIVE,
          CART_TYPE_WISHLIST
        ].includes(cleanType)
      ) {
        ErrorHandler.addError("Invalid cart type specified", {
          code: "INVALID_CART_TYPE",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          invalidType: cleanType,
          validTypes: [CART_TYPE_STANDARD, CART_TYPE_SHARED, CART_TYPE_COLLABORATIVE, CART_TYPE_WISHLIST],
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid cart type');
      }
      await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { cart_type: cleanType });

      Logger.debugLog?.(`[Cart] [setCartType] [SUCCESS] Successfully set cart type: sessionId=${cleanSessionId}, type=${cleanType}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "SET_CART_TYPE_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        type: cleanType,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "setCartType",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, type: cleanType, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async applyCoupon(sessionId, couponCode) {
    const operationName = 'applyCoupon';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      couponCode: { value: couponCode, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId, couponCode: cleanCouponCode } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [applyCoupon] [START] Applying coupon: sessionId=${cleanSessionId}, couponCode=${cleanCouponCode}`);

    try {
      // Additional validation for coupon code
      const sanitizedCouponCode = SafeUtils.sanitizeTextField(cleanCouponCode);
      if (!sanitizedCouponCode || !COUPON_CODE_PATTERN.test(sanitizedCouponCode)) {
        ErrorHandler.addError("Invalid coupon code specified", {
          code: "INVALID_COUPON_CODE",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          couponCode: cleanCouponCode,
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid coupon code format');
      }

      await ScyllaDb.updateItem(
        TABLE_CARTS,
        { session_id: cleanSessionId },
        { coupon_code: sanitizedCouponCode }
      );

      Logger.debugLog?.(`[Cart] [applyCoupon] [SUCCESS] Successfully applied coupon: sessionId=${cleanSessionId}, couponCode=${sanitizedCouponCode}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "APPLY_COUPON_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        couponCode: cleanCouponCode,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "applyCoupon",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, couponCode: cleanCouponCode, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async removeCoupon(sessionId) {
    const operationName = 'removeCoupon';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [removeCoupon] [START] Removing coupon: sessionId=${cleanSessionId}`);

    try {
      await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { coupon_code: null });

      Logger.debugLog?.(`[Cart] [removeCoupon] [SUCCESS] Successfully removed coupon: sessionId=${cleanSessionId}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "REMOVE_COUPON_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "removeCoupon",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async applyFees(sessionId, feeData = {}) {
    const operationName = 'applyFeesToCart';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      feeData: { value: feeData, type: "object", required: false, default: {} }
    }, operationName);

    const { sessionId: cleanSessionId, feeData: cleanFeeData } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [applyFees] [START] Applying fees: sessionId=${cleanSessionId}, feeData=${JSON.stringify(cleanFeeData)}`);

    try {
      // Deep sanitization: Create new object without dangerous keys or inherited properties
      const sanitizedFeeData = Object.create(null);
      for (const feeId in cleanFeeData) {
        if (DANGEROUS_KEYS.includes(feeId)) {
          ErrorHandler.addError("Dangerous key detected in fee data - potential prototype pollution", {
            code: "DANGEROUS_FEE_KEY_DETECTED",
            level: "error",
            origin: "Cart",
            sessionId: cleanSessionId,
            feeId: feeId,
            timestamp: DateTime.now(),
          });
          throw new Error('Operation failed');
        }
        
        // Validate fee structure
        const fee = cleanFeeData[feeId];
        if (!fee || typeof fee !== 'object' || !fee.type || typeof fee.value !== 'number') {
          ErrorHandler.addError("Invalid fee structure", {
            code: "INVALID_FEE_STRUCTURE",
            level: "error",
            origin: "Cart",
            sessionId: cleanSessionId,
            feeId: feeId,
            timestamp: DateTime.now(),
          });
          throw new Error('Operation failed');
        }
        
        // Validate fee value is within acceptable range
        if (fee.value < 0 || fee.value > MAX_FEE_VALUE) {
          ErrorHandler.addError("Fee value exceeds maximum allowed", {
            code: "FEE_VALUE_EXCEEDED",
            level: "error",
            origin: "Cart",
            sessionId: cleanSessionId,
            feeId: feeId,
            feeValue: fee.value,
            maxAllowed: MAX_FEE_VALUE,
            timestamp: DateTime.now(),
          });
          throw new Error('Operation failed');
        }
        
        sanitizedFeeData[feeId] = fee;
      }

      const cart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });
      const currentFees = cart?.fees || {};
      const mergedFees = Object.assign(Object.create(null), currentFees, sanitizedFeeData);
      await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { fees: mergedFees });

      Logger.debugLog?.(`[Cart] [applyFees] [SUCCESS] Successfully applied fees: sessionId=${cleanSessionId}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "APPLY_FEES_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        feeData: cleanFeeData,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "applyFeesToCart",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, feeData: cleanFeeData, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async applyCustomRules(sessionId, subscriptionDiscount = 0) {
    const operationName = 'applyCustomRules';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true },
      subscriptionDiscount: { value: subscriptionDiscount, type: "float", required: false, default: 0 }
    }, operationName);

    const { sessionId: cleanSessionId, subscriptionDiscount: cleanSubscriptionDiscount } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [applyCustomRules] [START] Applying custom rules: sessionId=${cleanSessionId}, subscriptionDiscount=${cleanSubscriptionDiscount}`);

    try {
      // Validate subscription discount range before proceeding
      if (cleanSubscriptionDiscount < 0 || cleanSubscriptionDiscount > 100) {
        ErrorHandler.addError("Subscription discount exceeds valid range", {
          code: "INVALID_SUBSCRIPTION_DISCOUNT",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          invalidDiscount: cleanSubscriptionDiscount,
          validRange: "0-100",
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      const summary = await Cart.getSummary(cleanSessionId);

      if (summary.grandTotal < Cart.MIN_CART_TOTAL) {
        ErrorHandler.addError("Cart total below minimum threshold", {
          code: "CART_TOTAL_BELOW_MINIMUM",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          currentTotal: summary.grandTotal,
          minimumRequired: Cart.MIN_CART_TOTAL,
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      if (summary.grandTotal > Cart.MAX_CART_TOTAL) {
        ErrorHandler.addError("Cart total exceeds maximum threshold", {
          code: "CART_TOTAL_EXCEEDS_MAXIMUM",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          currentTotal: summary.grandTotal,
          maximumAllowed: Cart.MAX_CART_TOTAL,
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      // Store discount as percentage for dynamic calculation, not fixed amount
      // This allows getSummary to calculate the actual discount dynamically
      await ScyllaDb.updateItem(
        TABLE_CARTS,
        { session_id: cleanSessionId },
        { plan_discount_percentage: cleanSubscriptionDiscount }
      );

      Logger.debugLog?.(`[Cart] [applyCustomRules] [SUCCESS] Successfully applied custom rules: sessionId=${cleanSessionId}, discountPercentage=${cleanSubscriptionDiscount}%`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "APPLY_CUSTOM_RULES_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        subscriptionDiscount: cleanSubscriptionDiscount,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "applyCustomRules",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, subscriptionDiscount: cleanSubscriptionDiscount, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async getSummary(sessionId) {
    const operationName = 'getCartSummary';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [getSummary] [START] Getting cart summary: sessionId=${cleanSessionId}`);

    try {
      const cart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });
      const items = cart?.items || {};
      let subtotal = 0;

      // Load products from configuration file using ConfigFileLoader with error handling
      let productsConfig;
      try {
        productsConfig = ConfigFileLoader.loadConfig("configs/products.json");
      } catch (configError) {
        ErrorHandler.addError("Failed to load products configuration", {
          code: "CONFIG_LOAD_FAILED",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          error: configError.message,
          timestamp: DateTime.now(),
        });
        throw new Error('Failed to load products configuration');
      }

      const products = productsConfig?.products || [];

      // Validate products configuration structure
      if (!Array.isArray(products)) {
        ErrorHandler.addError("Invalid products configuration structure", {
          code: "INVALID_PRODUCTS_CONFIG",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid products configuration structure');
      }

      // Create Map for O(1) product lookup
      const productMap = new Map(products.map(p => [p.product_id, p]));

      // Use Object.entries for safe iteration
      for (const [productId, item] of Object.entries(items)) {
        const product = productMap.get(productId);
        if (product) {
          const price = product?.price;

          // Validate price exists and is not zero
          if (typeof price !== 'number' || price <= 0) {
            ErrorHandler.addError("Invalid or missing product price", {
              code: "INVALID_PRODUCT_PRICE",
              level: "error",
              origin: "Cart",
              sessionId: cleanSessionId,
              productId: productId,
              price: price,
              timestamp: DateTime.now(),
            });
            throw new Error('Invalid product price detected');
          }

          const sanitizedQuantity = SafeUtils.sanitizeInteger(item?.quantity);
          const qty = sanitizedQuantity !== null ? sanitizedQuantity : 0;
          subtotal += qty * price;
        } else {
          // Product not found in config - this is a critical error
          ErrorHandler.addError("Product not found in configuration", {
            code: "PRODUCT_NOT_FOUND",
            level: "error",
            origin: "Cart",
            sessionId: cleanSessionId,
            productId: productId,
            timestamp: DateTime.now(),
          });
          throw new Error('Product not found in configuration');
        }
      }

      const fees = cart?.fees || {};
      let feesTotal = 0;
      // Use Object.entries for safe iteration
      for (const [feeId, fee] of Object.entries(fees)) {
        const amount = fee?.type === FEE_TYPE_PERCENTAGE ? ((fee?.value || 0) / PERCENTAGE_DIVISOR) * subtotal : (fee?.value || 0);
        feesTotal += amount;
      }

      // Support both old plan_discount (fixed amount) and new plan_discount_percentage (dynamic percentage)
      // Dynamic percentage discount is calculated at retrieval time based on current cart total
      const planDiscountPercentage = cart?.plan_discount_percentage || 0;
      const planDiscountFixed = cart?.plan_discount || 0;
      const planDiscount = planDiscountFixed + ((planDiscountPercentage / PERCENTAGE_DIVISOR) * (subtotal + feesTotal));
      const grandTotal = subtotal + feesTotal - planDiscount;

      // Apply coupon discount if coupon code is present
      let couponDiscount = 0;
      if (cart?.coupon_code) {
        // TODO: Implement coupon lookup from configuration or coupon service
        // For now, placeholder for coupon calculation logic
        // const couponConfig = await ConfigFileLoader.loadConfig('configs/coupons.json');
        // const coupon = couponConfig.coupons?.[cart.coupon_code];
        // if (coupon) {
        //   couponDiscount = coupon.type === 'percentage' ? (coupon.value / 100) * (subtotal + feesTotal) : coupon.value;
        // }
      }

      const finalTotal = Math.max(0, grandTotal - couponDiscount);

      const summary = {
        totalItems: Object.keys(items).length,
        subtotal,
        feesTotal,
        planDiscount,
        couponDiscount,
        grandTotal: finalTotal
      };

      Logger.debugLog?.(`[Cart] [getSummary] [SUCCESS] Retrieved cart summary: sessionId=${cleanSessionId}, grandTotal=${summary.grandTotal}`);

      return summary;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "GET_SUMMARY_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "getCartSummary",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  //* refactored code for the above function
  static async getAllCartsByUser(userId, limit = 100, lastEvaluatedKey = null) {
    const operationName = 'getAllCartsByUser';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      userId: { value: userId, type: "string", required: true },
      limit: { value: limit, type: "integer", required: false, default: 100 },
      lastEvaluatedKey: { value: lastEvaluatedKey, type: "object", required: false, default: null }
    }, operationName);

    const { userId: cleanUserId, limit: cleanLimit, lastEvaluatedKey: cleanLastEvaluatedKey } = sanitizedParams;

    // Validate pagination limit
    if (cleanLimit < 1 || cleanLimit > 1000) {
      ErrorHandler.addError("Invalid pagination limit", {
        code: "INVALID_PAGINATION_LIMIT",
        level: "error",
        origin: "Cart",
        userId: cleanUserId,
        limit: cleanLimit,
        timestamp: DateTime.now(),
      });
      throw new Error('Operation failed');
    }

    Logger.debugLog?.(`[Cart] [getAllCartsByUser] [START] Getting carts for user: userId=${cleanUserId}, limit=${cleanLimit}`);

    try {
      const keyConditionExpr = 'user_id = :uid';
      const queryParams = { ':uid': cleanUserId };
      const carts = await ScyllaDb.query(TABLE_CART_INDEX, keyConditionExpr, queryParams, {
        limit: cleanLimit,
        lastEvaluatedKey: cleanLastEvaluatedKey
      });

      Logger.debugLog?.(`[Cart] [getAllCartsByUser] [SUCCESS] Retrieved ${Array.isArray(carts) ? carts.length : 0} carts for user: userId=${cleanUserId}`);

      return carts;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "GET_ALL_CARTS_FAILED",
        level: "error",
        origin: "Cart",
        userId: cleanUserId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "getAllCartsByUser",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { userId: cleanUserId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async mergeGuestCartToUser(userId, sessionId) {
    const operationName = 'mergeGuestCartToUser';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      userId: { value: userId, type: "string", required: true },
      sessionId: { value: sessionId, type: "string", required: true }
    }, operationName);

    const { userId: cleanUserId, sessionId: cleanSessionId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [mergeGuestCartToUser] [START] Merging guest cart to user: userId=${cleanUserId}, sessionId=${cleanSessionId}`);

    try {
      // Validate user ID format
      if (!USER_ID_FORMAT_PATTERN.test(cleanUserId) || cleanUserId.length > MAX_USER_ID_LENGTH) {
        ErrorHandler.addError("Invalid user ID format", {
          code: "INVALID_USER_ID_FORMAT",
          level: "error",
          origin: "Cart",
          userId: cleanUserId.substring(0, 50),
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid user ID format');
      }

      const guestCart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });
      if (!guestCart) {
        Logger.debugLog?.(`[Cart] [mergeGuestCartToUser] [SKIP] No guest cart found: sessionId=${cleanSessionId}`);
        return Cart;
      }

      // Check if cart already has a user_id
      if (guestCart.user_id) {
        ErrorHandler.addError("Cart already associated with a user", {
          code: "CART_ALREADY_ASSOCIATED",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          existingUserId: guestCart.user_id,
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      const nowTimestamp = DateTime.now();
      const createdAtTimestamp = typeof nowTimestamp === 'number' ? Math.floor(nowTimestamp / MS_TO_SECONDS) : Math.floor(Date.now() / MS_TO_SECONDS);

      // Use original cart created_at for index timestamp consistency
      const originalCreatedAt = guestCart.created_at || createdAtTimestamp;

      // Use transactional write to ensure atomicity between cart and index updates
      const transactWriteOperations = [
        {
          table: TABLE_CART_INDEX,
          action: 'put',
          key: { user_id: cleanUserId, session_id: cleanSessionId },
          data: {
            user_id: cleanUserId,
            session_id: cleanSessionId,
            is_default: false,
            created_at: originalCreatedAt,
          }
        },
        {
          table: TABLE_CARTS,
          action: 'update',
          key: { session_id: cleanSessionId },
          data: { user_id: cleanUserId }
        }
      ];

      try {
        await ScyllaDb.transactWrite(transactWriteOperations, {
          rollbackOnFailure: true
        });
        
        // Verify transaction succeeded
        const verifyCart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });
        const verifyIndex = await ScyllaDb.getItem(TABLE_CART_INDEX, { user_id: cleanUserId, session_id: cleanSessionId });
        
        if (!verifyCart?.user_id || !verifyIndex) {
          ErrorHandler.addError("Transaction state verification failed", {
            code: "TRANSACT_VERIFY_FAILED",
            level: "error",
            origin: "Cart",
            userId: cleanUserId,
            sessionId: cleanSessionId,
            cartHasUserId: !!verifyCart?.user_id,
            indexExists: !!verifyIndex,
            timestamp: DateTime.now(),
          });
          throw new Error('Operation failed');
        }
      } catch (transactError) {
        ErrorHandler.addError("Transaction failed during merge", {
          code: "MERGE_TRANSACT_FAILED",
          level: "error",
          origin: "Cart",
          userId: cleanUserId,
          sessionId: cleanSessionId,
          error: transactError.message,
          timestamp: DateTime.now(),
        });
        throw transactError;
      }

      Logger.debugLog?.(`[Cart] [mergeGuestCartToUser] [SUCCESS] Successfully merged guest cart to user: userId=${cleanUserId}, sessionId=${cleanSessionId}`);

      return Cart; //* returning Cart for chaining
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "MERGE_GUEST_CART_FAILED",
        level: "error",
        origin: "Cart",
        userId: cleanUserId,
        sessionId: cleanSessionId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "mergeGuestCartToUser",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { userId: cleanUserId, sessionId: cleanSessionId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async attachLiveData(sessionId) {
    const operationName = 'attachLiveData';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [attachLiveData] [START] Attaching live data: sessionId=${cleanSessionId}`);

    try {
      const cart = await ScyllaDb.getItem(TABLE_CARTS, { session_id: cleanSessionId });
      const items = cart?.items || {};

      // Load live data templates from configuration file with error handling
      let liveDataConfig;
      try {
        liveDataConfig = ConfigFileLoader.loadConfig("configs/liveDataTemplates.json");
      } catch (configError) {
        ErrorHandler.addError("Failed to load live data templates configuration", {
          code: "CONFIG_LOAD_FAILED",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          error: configError.message,
          timestamp: DateTime.now(),
        });
        throw new Error('Failed to load live data templates configuration');
      }

      const templates = liveDataConfig?.liveDataTemplates;

      // Validate templates structure
      if (!templates || typeof templates !== 'object') {
        ErrorHandler.addError("Invalid live data templates structure", {
          code: "INVALID_TEMPLATES_STRUCTURE",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          timestamp: DateTime.now(),
        });
        throw new Error('Invalid live data templates structure');
      }

      if (!templates?.titleTemplate || !templates?.thumbUrlTemplate || !templates?.creatorTemplate) {
        ErrorHandler.addError("Missing required template properties in live data configuration", {
          code: "MISSING_TEMPLATE_PROPERTIES",
          level: "error",
          origin: "Cart",
          sessionId: cleanSessionId,
          hasTemplates: !!templates,
          hasTitleTemplate: !!templates?.titleTemplate,
          hasThumbUrlTemplate: !!templates?.thumbUrlTemplate,
          hasCreatorTemplate: !!templates?.creatorTemplate,
          timestamp: DateTime.now(),
        });
        throw new Error('Missing required template properties');
      }

      for (const productId of Object.keys(items)) {
        // Validate product ID exists
        if (!items[productId]) continue;

        // Sanitize productId for URL template usage
        const sanitizedProductId = SafeUtils.sanitizeString(productId);
        if (sanitizedProductId) {
          if (!items[productId]) items[productId] = {};
          // Sanitize all template outputs
          items[productId].title = SafeUtils.sanitizeTextField(templates.titleTemplate.replace('{productId}', sanitizedProductId)) || '';
          // Sanitize URL templates using SafeUtils
          items[productId].thumb = SafeUtils.sanitizeUrl(templates.thumbUrlTemplate.replace('{productId}', sanitizedProductId)) || '';
          items[productId].creator = SafeUtils.sanitizeTextField(templates.creatorTemplate.replace('{productId}', sanitizedProductId)) || '';
        }
      }

      await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cleanSessionId }, { items });

      Logger.debugLog?.(`[Cart] [attachLiveData] [SUCCESS] Successfully attached live data: sessionId=${cleanSessionId}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "ATTACH_LIVE_DATA_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "attachLiveData",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async convertToWishlist(sessionId) {
    const operationName = 'convertToWishList';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [convertToWishlist] [START] Converting cart to wishlist: sessionId=${cleanSessionId}`);

    try {
      const result = await Cart.setCartType(cleanSessionId, CART_TYPE_WISHLIST);

      Logger.debugLog?.(`[Cart] [convertToWishlist] [SUCCESS] Successfully converted cart to wishlist: sessionId=${cleanSessionId}`);

      return result;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "CONVERT_TO_WISHLIST_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "convertToWishList",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async priceAlerts(sessionId) {
    const operationName = 'priceAlerts';

    // Sanitize and validate input parameters using SafeUtils
    const sanitizedParams = SafeUtils.sanitizeValidate({
      sessionId: { value: sessionId, type: "string", required: true }
    }, operationName);

    const { sessionId: cleanSessionId } = sanitizedParams;

    Logger.debugLog?.(`[Cart] [priceAlerts] [START] Processing price alerts: sessionId=${cleanSessionId}`);

    try {
      // Placeholder for price alert logic

      Logger.debugLog?.(`[Cart] [priceAlerts] [SUCCESS] Price alerts processed: sessionId=${cleanSessionId}`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError(`Failed to ${operationName}`, {
        code: "PRICE_ALERTS_FAILED",
        level: "error",
        origin: "Cart",
        sessionId: cleanSessionId,
        error: error.message,
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "priceAlerts",
        level: "error",
        message: `Failed to ${operationName}`,
        data: { sessionId: cleanSessionId, error: error.message }
      }).catch(() => { });
      throw error;
    }
  }

  static async remindAbandonedCarts(pageSize = 100, lastEvaluatedKey = null) {
    Logger.debugLog?.(`[Cart] [remindAbandonedCarts] [START] Checking for abandoned carts, pageSize=${pageSize}`);

    const nowTimestamp = DateTime.now();
    const now = typeof nowTimestamp === 'number' ? Math.floor(nowTimestamp / MS_TO_SECONDS) : Math.floor(Date.now() / MS_TO_SECONDS);
    const halfTTL = Cart.CART_TTL_MILLISECONDS / (2 * MS_TO_SECONDS); // Convert to seconds
    const cutoffTime = now - halfTTL;
    const reminderCooldown = 86400; // 24 hours in seconds

    try {
      // Validate page size
      if (pageSize < 1 || pageSize > 1000) {
        ErrorHandler.addError("Invalid page size for abandoned cart scan", {
          code: "INVALID_PAGE_SIZE",
          level: "error",
          origin: "Cart",
          pageSize: pageSize,
          timestamp: DateTime.now(),
        });
        throw new Error('Operation failed');
      }

      // Use paginated scan instead of full table scan
      const idleCarts = await ScyllaDb.scan(TABLE_CARTS, {
        FilterExpression: '#created_at < :cutoff AND #last_reminded_at < :reminderCutoff',
        ExpressionAttributeNames: {
          '#created_at': 'created_at',
          '#last_reminded_at': 'last_reminded_at'
        },
        ExpressionAttributeValues: {
          ':cutoff': cutoffTime,
          ':reminderCutoff': now - reminderCooldown
        },
        limit: pageSize,
        lastEvaluatedKey: lastEvaluatedKey
      });

      let remindersProcessed = 0;
      const cartsToProcess = Array.isArray(idleCarts) ? idleCarts : (idleCarts ? [idleCarts] : []);

      for (const cart of cartsToProcess) {
        try {
          Logger.debugLog?.(`[Cart] [remindAbandonedCarts] [REMINDER_SENT] Reminder: Cart ${cart.session_id} is idle.`);
          // Update last_reminded_at timestamp
          await ScyllaDb.updateItem(TABLE_CARTS, { session_id: cart.session_id }, { last_reminded_at: now });
          remindersProcessed++;
          // 👉 Here you could trigger an email, notification, etc.
        } catch (itemError) {
          ErrorHandler.addError("Failed to process individual cart reminder", {
            code: "CART_REMINDER_FAILED",
            level: "warn",
            origin: "Cart",
            sessionId: cart.session_id,
            error: itemError.message,
            timestamp: DateTime.now(),
          });
          // Continue processing other carts
        }
      }

      Logger.debugLog?.(`[Cart] [remindAbandonedCarts] [SUCCESS] Processed ${remindersProcessed}/${cartsToProcess.length} abandoned cart reminders`);

      return Cart;
    } catch (error) {
      ErrorHandler.addError("Failed to remind abandoned carts", {
        code: "REMIND_ABANDONED_CARTS_FAILED",
        level: "error",
        origin: "Cart",
        error: error.message,
        cutoffTime,
        halfTTL: Cart.CART_TTL_MILLISECONDS / (2 * MS_TO_SECONDS),
        timestamp: DateTime.now(),
      });
      await Logger.writeLog({
        flag: "CART",
        action: "remindAbandonedCarts",
        level: "error",
        message: "Failed to remind abandoned carts",
        data: { error: error.message, cutoffTime, halfTTL: Cart.CART_TTL_MILLISECONDS / (2 * MS_TO_SECONDS) }
      }).catch(() => { });
      // Don't throw since this is a background operation
      return Cart;
    }
  }
}

module.exports = Cart;
